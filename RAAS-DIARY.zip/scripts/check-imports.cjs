const fs = require('fs');
const path = require('path');

function checkImports(file) {
  const content = fs.readFileSync(file, 'utf8');
  const importRegex = /from\s+['"](\.[^'"]+)['"]/g;
  let match;
  while ((match = importRegex.exec(content)) !== null) {
    const relPath = match[1];
    const dir = path.dirname(file);
    const resolved = path.resolve(dir, relPath);
    const candidates = [
      resolved,
      resolved + '.ts',
      resolved + '.tsx',
      resolved + '.js',
      resolved + '.jsx',
      path.join(resolved, 'index.ts'),
      path.join(resolved, 'index.tsx')
    ];
    let found = false;
    let actualFile = null;
    for (const c of candidates) {
      if (fs.existsSync(c)) {
        found = true;
        actualFile = c;
        break;
      }
    }
    if (!found) {
      console.log('MISSING import in', file, '->', relPath);
    } else {
      const baseName = path.basename(actualFile);
      const parentDir = path.dirname(actualFile);
      const entries = fs.readdirSync(parentDir);
      if (!entries.includes(baseName)) {
        console.log('CASING MISMATCH in', file, '->', relPath, 'actual:', entries.find(e => e.toLowerCase() === baseName.toLowerCase()), 'vs', baseName);
      }
    }
  }
}

function walk(dir) {
  for (const f of fs.readdirSync(dir)) {
    if (f === 'node_modules' || f === 'dist' || f === '.git') continue;
    const p = path.join(dir, f);
    if (fs.statSync(p).isDirectory()) walk(p);
    else if (/\.(ts|tsx)$/.test(f)) checkImports(p);
  }
}
walk('./src');
walk('./server');
console.log('Check complete.');
