import React, { useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import {
  CheckCircle2,
  Cloud,
  ExternalLink,
  Laptop,
  Server,
  ShieldCheck,
  Smartphone,
  X,
  Zap,
} from 'lucide-react';

interface CloudHostingModalProps {
  isOpen?: boolean;
  open?: boolean;
  onClose: () => void;
}

export const CloudHostingModal: React.FC<CloudHostingModalProps> = ({
  isOpen,
  open,
  onClose,
}) => {
  const visible = open ?? isOpen ?? false;
  const [activeTab, setActiveTab] = useState<'why' | 'render' | 'railway'>('render');

  if (!visible) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="absolute inset-0 bg-black/70 backdrop-blur-md"
        />

        {/* Modal Window */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 16 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 16 }}
          className="relative w-full max-w-2xl bg-[var(--surface)]/95 border border-white/15 rounded-3xl p-5 sm:p-7 shadow-[0_24px_64px_rgba(0,0,0,0.6)] backdrop-blur-2xl z-10 overflow-hidden my-auto"
        >
          {/* Header */}
          <div className="flex items-start justify-between gap-3 pb-4 border-b border-white/10">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center text-white shadow-lg shadow-blue-500/25 shrink-0">
                <Cloud className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-white tracking-tight flex items-center gap-2">
                  24/7 Cloud Hosting Guide
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 font-semibold border border-emerald-500/30">
                    100% Free
                  </span>
                </h3>
                <p className="text-xs text-[var(--text-secondary)]">
                  Keep Raa's Diary active 24/7 on iPhone and Android even when your laptop is turned off
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 rounded-xl hover:bg-white/10 text-[var(--text-muted)] hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Navigation Pills */}
          <div className="flex gap-2 my-4 p-1 bg-white/5 rounded-2xl border border-white/10">
            <button
              onClick={() => setActiveTab('why')}
              className={`flex-1 py-2 rounded-xl text-xs font-semibold transition-all ${
                activeTab === 'why'
                  ? 'bg-gradient-to-r from-blue-500 to-indigo-600 text-white shadow-md'
                  : 'text-[var(--text-secondary)] hover:text-white'
              }`}
            >
              1. Local vs Cloud
            </button>
            <button
              onClick={() => setActiveTab('render')}
              className={`flex-1 py-2 rounded-xl text-xs font-semibold transition-all ${
                activeTab === 'render'
                  ? 'bg-gradient-to-r from-blue-500 to-indigo-600 text-white shadow-md'
                  : 'text-[var(--text-secondary)] hover:text-white'
              }`}
            >
              2. Render.com (Free 24/7)
            </button>
            <button
              onClick={() => setActiveTab('railway')}
              className={`flex-1 py-2 rounded-xl text-xs font-semibold transition-all ${
                activeTab === 'railway'
                  ? 'bg-gradient-to-r from-blue-500 to-indigo-600 text-white shadow-md'
                  : 'text-[var(--text-secondary)] hover:text-white'
              }`}
            >
              3. Ready Files
            </button>
          </div>

          {/* Content Body */}
          <div className="space-y-4 max-h-[60vh] overflow-y-auto pr-1 no-scrollbar text-xs sm:text-[13px] leading-relaxed text-[var(--text-secondary)]">
            {activeTab === 'why' && (
              <div className="space-y-3.5">
                <div className="p-4 rounded-2xl bg-blue-500/10 border border-blue-500/20 text-white space-y-2">
                  <div className="font-semibold text-blue-300 flex items-center gap-2">
                    <Laptop className="w-4 h-4" /> Why does the app pause when laptop sleeps?
                  </div>
                  <p className="text-xs text-blue-100/90 leading-relaxed">
                    When running on <b>localhost:3000</b>, your laptop acts as the host server. When the laptop goes to sleep or is closed, local networking is halted.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                  <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 space-y-2">
                    <div className="font-bold text-emerald-400 flex items-center gap-1.5">
                      <ShieldCheck className="w-4 h-4" /> Solution 1: Offline PWA Mode (Active)
                    </div>
                    <p className="text-xs text-[var(--text-muted)]">
                      We have integrated <b>automatic offline storage</b>. Even if the server pauses, all diary logs, tasks, and routines remain cached locally on your device.
                    </p>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 space-y-2">
                    <div className="font-bold text-indigo-400 flex items-center gap-1.5">
                      <Zap className="w-4 h-4" /> Solution 2: Cloud Hosting (24/7 Live)
                    </div>
                    <p className="text-xs text-[var(--text-muted)]">
                      Deploy for free on <b>Render.com</b>. Your app runs in the cloud permanently with zero laptop dependencies, accessible worldwide.
                    </p>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'render' && (
              <div className="space-y-3">
                <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 space-y-2">
                  <div className="font-bold text-white flex items-center gap-2">
                    <Server className="w-4 h-4 text-blue-400" />
                    How to Deploy on Render.com in 2 Minutes:
                  </div>
                  <ol className="list-decimal list-inside space-y-2 text-xs text-[var(--text-secondary)]">
                    <li>
                      <b className="text-white">Push to GitHub</b>: Your repository is already synchronized on GitHub.
                    </li>
                    <li>
                      <b className="text-white">Open Render.com</b>:{' '}
                      <a
                        href="https://render.com"
                        target="_blank"
                        rel="noreferrer"
                        className="text-blue-400 underline inline-flex items-center gap-0.5"
                      >
                        render.com <ExternalLink className="w-3 h-3" />
                      </a>{' '}
                      and sign in.
                    </li>
                    <li>
                      <b className="text-white">Select Web Service</b>: Click on your service (`Raa's diary`).
                    </li>
                    <li>
                      <b className="text-white">Manual Deploy</b>: Click <b>Manual Deploy</b> &gt; <b>Clear build cache &amp; deploy</b>.
                    </li>
                  </ol>
                </div>

                <div className="p-3 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 text-xs flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
                  <span>
                    Your permanent URL: <b>https://raas-diary.onrender.com</b>. Ready for all devices 24/7.
                  </span>
                </div>
              </div>
            )}

            {activeTab === 'railway' && (
              <div className="space-y-3">
                <p className="text-xs">
                  All deployment configuration files are already set up in the root repository:
                </p>

                <div className="space-y-2">
                  <div className="p-3 rounded-xl bg-white/5 border border-white/10 flex items-center justify-between">
                    <div>
                      <div className="font-semibold text-white">Dockerfile</div>
                      <div className="text-[11px] text-[var(--text-muted)]">
                        Production multi-stage container for Render, Railway, Fly.io
                      </div>
                    </div>
                    <span className="text-[11px] px-2 py-0.5 rounded-md bg-white/10 text-white">
                      In project root
                    </span>
                  </div>

                  <div className="p-3 rounded-xl bg-white/5 border border-white/10 flex items-center justify-between">
                    <div>
                      <div className="font-semibold text-white">render.yaml</div>
                      <div className="text-[11px] text-[var(--text-muted)]">
                        Render Blueprint auto-deploy specification
                      </div>
                    </div>
                    <span className="text-[11px] px-2 py-0.5 rounded-md bg-white/10 text-white">
                      Configured
                    </span>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Footer */}
          <div className="mt-5 pt-3 border-t border-white/10 flex items-center justify-between">
            <span className="text-[11px] text-[var(--text-muted)] flex items-center gap-1.5">
              <Smartphone className="w-3.5 h-3.5 text-blue-400" />
              iPhone &amp; Android PWA Compatible
            </span>
            <button
              onClick={onClose}
              className="px-5 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white font-semibold text-xs transition-colors"
            >
              Close
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
