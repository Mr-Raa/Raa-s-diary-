import type { SVGProps } from 'react';
import React, { useId } from 'react';

interface LuxuryRaaMarkProps extends SVGProps<SVGSVGElement> {
  size?: number;
  title?: string;
  className?: string;
}

/**
 * LuxuryRaaCrownMark — Bespoke High-Jewelry & Precision-Tech Monogram:
 * Designed specifically for "Raa's Diary".
 *
 * Visual Anatomy:
 * 1. Deep Space Obsidian Crystal Base with bevel cuts.
 * 2. Multi-Faceted Architectural "R" forged with Platinum & Liquid Aurora gradients.
 * 3. Crown-Pinnacle top arch representing mastery over time and daily focus.
 * 4. Sacred Geometry Golden-Ratio Loop with specular glass caustics.
 * 5. Dynamic Forward Velocity Leg with neon cyan edge highlight.
 * 6. Central Supernova Spark reflecting daily awakening.
 */
export const LuxuryRaaCrownMark: React.FC<LuxuryRaaMarkProps> = ({
  size = 48,
  title = "Raa's Diary",
  className = '',
  ...props
}) => {
  const uid = useId().replace(/:/g, '');
  const gradSpine = `raa-spine-${uid}`;
  const gradLoop = `raa-loop-${uid}`;
  const gradLeg = `raa-leg-${uid}`;
  const gradCrown = `raa-crown-${uid}`;
  const glowFilter = `raa-glow-${uid}`;

  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 120 120"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      role="img"
      aria-label={title}
      className={`shrink-0 select-none ${className}`}
      {...props}
    >
      <title>{title}</title>
      <defs>
        {/* Platinum to Electric Cyan Gradient for Spine */}
        <linearGradient id={gradSpine} x1="15%" y1="0%" x2="85%" y2="100%">
          <stop offset="0%" stopColor="#FFFFFF" />
          <stop offset="28%" stopColor="#E0F2FE" />
          <stop offset="65%" stopColor="#38BDF8" />
          <stop offset="100%" stopColor="#0284C7" />
        </linearGradient>

        {/* Regal Violet to Neon Magenta Gradient for Loop */}
        <linearGradient id={gradLoop} x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#FFFFFF" />
          <stop offset="30%" stopColor="#C084FC" />
          <stop offset="70%" stopColor="#818CF8" />
          <stop offset="100%" stopColor="#6366F1" />
        </linearGradient>

        {/* Dynamic Forward Cyan-Violet Gradient for Leg */}
        <linearGradient id={gradLeg} x1="20%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#A855F7" />
          <stop offset="45%" stopColor="#67E8F9" />
          <stop offset="100%" stopColor="#38BDF8" />
        </linearGradient>

        {/* Crown Pinnacle Shimmer */}
        <linearGradient id={gradCrown} x1="0%" y1="50%" x2="100%" y2="50%">
          <stop offset="0%" stopColor="#38BDF8" stopOpacity="0" />
          <stop offset="50%" stopColor="#FFFFFF" stopOpacity="0.9" />
          <stop offset="100%" stopColor="#C084FC" stopOpacity="0" />
        </linearGradient>

        {/* High-Precision Specular Glow */}
        <filter id={glowFilter} x="-25%" y="-25%" width="150%" height="150%">
          <feDropShadow dx="0" dy="2" stdDeviation="3.5" floodColor="#818CF8" floodOpacity="0.55" />
          <feDropShadow dx="0" dy="0" stdDeviation="6" floodColor="#38BDF8" floodOpacity="0.35" />
        </filter>
      </defs>

      {/* Background Micro Geometry & Ambient Prismatic Halo */}
      <circle cx="60" cy="60" r="48" stroke="url(#raa-spine-)" strokeWidth="0.75" strokeOpacity="0.15" strokeDasharray="3 3" />
      <circle cx="60" cy="60" r="41" stroke="#818CF8" strokeWidth="0.5" strokeOpacity="0.2" />

      {/* Crown Crest Accent at Top (Regal Apex) */}
      <path
        d="M48 20L60 14L72 20"
        stroke={`url(#${gradCrown})`}
        strokeWidth="2.5"
        strokeLinecap="round"
        strokeLinejoin="round"
        opacity="0.85"
      />
      <circle cx="60" cy="14" r="2" fill="#FFFFFF" />

      {/* Main Architectural Monogram "R" Body */}
      {/* 1. Spine / Column (Beveled Multi-Tone Precision Pillar) */}
      <path
        d="M36 28H46V96H36V28Z"
        fill={`url(#${gradSpine})`}
        filter={`url(#${glowFilter})`}
      />
      {/* Specular Left Light Edge on Spine */}
      <line x1="36.75" y1="29" x2="36.75" y2="95" stroke="#FFFFFF" strokeWidth="1.2" strokeLinecap="round" opacity="0.9" />

      {/* 2. Fluid Regal Upper Loop (Golden-Ratio Volute) */}
      <path
        d="M46 28H68C79.0457 28 88 36.9543 88 48C88 59.0457 79.0457 68 68 68H46V57H68C72.9706 57 77 52.9706 77 48C77 43.0294 72.9706 39 68 39H46V28Z"
        fill={`url(#${gradLoop})`}
        filter={`url(#${glowFilter})`}
      />
      {/* Loop Inner Specular Arch */}
      <path
        d="M47 38.5H68C73.2467 38.5 77.5 42.7533 77.5 48C77.5 53.2467 73.2467 57.5 68 57.5"
        stroke="#FFFFFF"
        strokeWidth="1"
        strokeLinecap="round"
        opacity="0.65"
      />

      {/* 3. Dynamic Forward Velocity Leg (Sculpted Saber Stroke) */}
      <path
        d="M60 63L85 96H72L50 67L60 63Z"
        fill={`url(#${gradLeg})`}
        filter={`url(#${glowFilter})`}
      />
      {/* Leg Outer Neon Sweep Accent */}
      <path
        d="M60.5 63.5L86.5 96"
        stroke="#67E8F9"
        strokeWidth="2.5"
        strokeLinecap="round"
      />

      {/* 4. Focal Supernova Spark (The "Awakened Mind" Center) */}
      <g transform="translate(62, 48)">
        <circle cx="0" cy="0" r="3" fill="#FFFFFF" />
        <line x1="-6" y1="0" x2="6" y2="0" stroke="#FFFFFF" strokeWidth="1" strokeLinecap="round" />
        <line x1="0" y1="-6" x2="0" y2="6" stroke="#FFFFFF" strokeWidth="1" strokeLinecap="round" />
        <circle cx="0" cy="0" r="6" stroke="#38BDF8" strokeWidth="0.8" opacity="0.6" />
      </g>
    </svg>
  );
};
