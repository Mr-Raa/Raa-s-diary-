import type { SVGProps } from 'react';
import React, { useId } from 'react';

interface LuxuryRaaMarkProps extends SVGProps<SVGSVGElement> {
  size?: number;
  title?: string;
  className?: string;
}

/**
 * LuxuryRaaCrownMark — Exact Image 15 Design:
 * "હવે આ દિશા વધારે નજીક છે ભાઈ. ❤️"
 *
 * Visual Components:
 * 1. Deep space rounded squircle with double specular glass rim & violet neon aura.
 * 2. Luminous celestial orbit ring wrapping in 3D around the monogram.
 * 3. Left architectural pillar with conscious beacon dot at the apex.
 * 4. Sculpted liquid chrome & violet fluid "R" with dynamic forward sweep leg.
 * 5. Brilliant 4-point diamond sparkle inside the focal center.
 */
export const LuxuryRaaCrownMark: React.FC<LuxuryRaaMarkProps> = ({
  size = 48,
  title = "Raa's Diary",
  className = '',
  ...props
}) => {
  const uid = useId().replace(/:/g, '');
  const bgGrad = `raa-bg-${uid}`;
  const rimGrad = `raa-rim-${uid}`;
  const rGrad = `raa-r-${uid}`;
  const orbitGrad = `raa-orbit-${uid}`;
  const glowFilter = `raa-glow-${uid}`;

  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 128 128"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      role="img"
      aria-label={title}
      className={`shrink-0 select-none ${className}`}
      {...props}
    >
      <title>{title}</title>
      <defs>
        {/* Deep Space Squircle Background */}
        <radialGradient id={bgGrad} cx="40%" cy="30%" r="75%">
          <stop offset="0%" stopColor="#1a1333" />
          <stop offset="45%" stopColor="#0c0a1a" />
          <stop offset="100%" stopColor="#030208" />
        </radialGradient>

        {/* Specular Violet-to-Cyan Edge Rim */}
        <linearGradient id={rimGrad} x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#FFFFFF" stopOpacity="0.85" />
          <stop offset="35%" stopColor="#C084FC" stopOpacity="0.65" />
          <stop offset="70%" stopColor="#818CF8" stopOpacity="0.5" />
          <stop offset="100%" stopColor="#38BDF8" stopOpacity="0.75" />
        </linearGradient>

        {/* Liquid Chrome-to-Violet Gradient for the 'R' */}
        <linearGradient id={rGrad} x1="15%" y1="10%" x2="90%" y2="95%">
          <stop offset="0%" stopColor="#FFFFFF" />
          <stop offset="32%" stopColor="#EDE9FE" />
          <stop offset="68%" stopColor="#C084FC" />
          <stop offset="100%" stopColor="#818CF8" />
        </linearGradient>

        {/* Celestial Orbit Gradient */}
        <linearGradient id={orbitGrad} x1="0%" y1="100%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="#818CF8" stopOpacity="0.1" />
          <stop offset="40%" stopColor="#C084FC" stopOpacity="0.8" />
          <stop offset="65%" stopColor="#FFFFFF" stopOpacity="0.95" />
          <stop offset="100%" stopColor="#38BDF8" stopOpacity="0.2" />
        </linearGradient>

        {/* Specular Glow Filter */}
        <filter id={glowFilter} x="-20%" y="-20%" width="140%" height="140%">
          <feDropShadow dx="0" dy="2" stdDeviation="4" floodColor="#A855F7" floodOpacity="0.6" />
          <feDropShadow dx="0" dy="0" stdDeviation="8" floodColor="#818CF8" floodOpacity="0.4" />
        </filter>
      </defs>

      {/* 1. Base Squircle with Liquid Glass Rim */}
      <rect x="4" y="4" width="120" height="120" rx="32" fill={`url(#${bgGrad})`} />
      <rect
        x="4.75"
        y="4.75"
        width="118.5"
        height="118.5"
        rx="31.25"
        fill="none"
        stroke={`url(#${rimGrad})`}
        strokeWidth="1.5"
      />

      {/* Inner ambient glow blur */}
      <circle cx="64" cy="64" r="38" fill="#818CF8" opacity="0.15" filter="blur(16px)" />

      {/* 2. Celestial Orbit Ring (tilted ellipse behind the leg and in front of the stem) */}
      <ellipse
        cx="64"
        cy="64"
        rx="50"
        ry="22"
        transform="rotate(-28 64 64)"
        fill="none"
        stroke={`url(#${orbitGrad})`}
        strokeWidth="1.8"
        strokeDasharray="180 30"
        opacity="0.85"
      />

      {/* 3. The Stylized Luxury 'R' (Image 15 Style) */}
      <g filter={`url(#${glowFilter})`}>
        {/* Left Column Stem with Human/Conscious Dot */}
        {/* Dot Beacon at Apex */}
        <circle cx="36" cy="33" r="5" fill={`url(#${rGrad})`} />
        <circle cx="36" cy="33" r="2" fill="#FFFFFF" />

        {/* Left Pillar Body */}
        <path
          d="M32 44C32 44 43 52 43 72C43 86 32 96 32 96H44C44 96 52 86 52 70C52 54 44 44 44 44H32Z"
          fill={`url(#${rGrad})`}
        />

        {/* Elegant Fluid Upper Loop */}
        <path
          d="M48 41C54 36 65 33 76 33C92 33 102 43 102 56C102 68 91 76 77 76C68 76 59 74 54 71L58 62C63 65 70 67 76 67C85 67 91 62 91 55C91 48 84 43 74 43C66 43 57 46 51 50L48 41Z"
          fill={`url(#${rGrad})`}
        />

        {/* Dynamic Forward Velocity Leg */}
        <path
          d="M66 69C73 69 82 78 95 97H81C71 83 65 78 57 76L66 69Z"
          fill={`url(#${rGrad})`}
        />
        {/* Saber Highlight Stroke on Leg */}
        <path
          d="M67 70C74 72 83 82 96 97"
          stroke="#FFFFFF"
          strokeWidth="1.8"
          strokeLinecap="round"
          opacity="0.9"
        />

        {/* 4. Center 4-Point Diamond Sparkle */}
        <g transform="translate(68, 54)">
          <path
            d="M0 -7C0.5 -2 2 -0.5 7 0C2 0.5 0.5 2 0 7C-0.5 2 -2 0.5 -7 0C-2 -0.5 -0.5 -2 0 -7Z"
            fill="#FFFFFF"
          />
          <circle cx="0" cy="0" r="1.5" fill="#C084FC" />
        </g>
      </g>
    </svg>
  );
};

export default LuxuryRaaCrownMark;
