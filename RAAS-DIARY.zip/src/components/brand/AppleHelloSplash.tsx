import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { LuxuryRaaCrownMark } from './LuxuryRaaCrownMark';

interface AppleHelloSplashProps {
  onComplete: () => void;
  durationMs?: number;
}

/**
 * AppleHelloSplash — Iconic iPhone-style Liquid Glass "hello" Startup Experience:
 * - Fluid cursive handwritten "hello" stroke animation.
 * - Dynamic liquid glass frosted refraction aura.
 * - Regal "Raa's Diary — Personal Life OS" reveal.
 * - Smooth dismissal into the dashboard with spring easing.
 */
export const AppleHelloSplash: React.FC<AppleHelloSplashProps> = ({
  onComplete,
  durationMs = 2400,
}) => {
  const [phase, setPhase] = useState<'hello' | 'reveal' | 'exit'>('hello');

  useEffect(() => {
    // Phase 1: 'hello' handwriting runs for 1.3s
    const t1 = window.setTimeout(() => {
      setPhase('reveal');
    }, 1300);

    // Phase 2: 'reveal' shows the brand monogram & title until duration
    const t2 = window.setTimeout(() => {
      setPhase('exit');
    }, durationMs - 400);

    // Phase 3: trigger onComplete after exit animation finishes
    const t3 = window.setTimeout(() => {
      onComplete();
    }, durationMs);

    return () => {
      window.clearTimeout(t1);
      window.clearTimeout(t2);
      window.clearTimeout(t3);
    };
  }, [durationMs, onComplete]);

  return (
    <AnimatePresence>
      {phase !== 'exit' && (
        <motion.div
          key="apple-hello-splash"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0, scale: 1.04, filter: 'blur(12px)' }}
          transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
          onClick={onComplete}
          className="fixed inset-0 z-[99999] flex flex-col items-center justify-center bg-[#05070e] select-none cursor-pointer overflow-hidden px-4"
          style={{
            paddingTop: 'env(safe-area-inset-top, 24px)',
            paddingBottom: 'env(safe-area-inset-bottom, 24px)',
          }}
          aria-label="Welcome to Raa's Diary"
        >
          {/* Ambient Liquid Glass Aurora Background Glow */}
          <div
            className="absolute w-[360px] h-[360px] sm:w-[540px] sm:h-[540px] rounded-full blur-[90px] sm:blur-[140px] pointer-events-none opacity-40 animate-pulse"
            style={{
              background:
                'radial-gradient(circle at 40% 40%, rgba(139, 92, 246, 0.45), rgba(56, 189, 248, 0.35) 45%, rgba(236, 72, 153, 0.2) 75%, transparent 100%)',
            }}
          />

          {/* Micro Star Dust Grid Backdrop */}
          <div
            className="absolute inset-0 opacity-[0.035] pointer-events-none"
            style={{
              backgroundImage:
                'radial-gradient(rgba(255, 255, 255, 0.8) 1px, transparent 1px)',
              backgroundSize: '28px 28px',
            }}
          />

          <div className="relative z-10 flex flex-col items-center justify-center text-center max-w-sm sm:max-w-md w-full">
            {/* Phase 1: Apple's Iconic Cursive "hello" Handwriting Animation */}
            {phase === 'hello' && (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, y: -16, filter: 'blur(8px)' }}
                transition={{ duration: 0.4 }}
                className="flex flex-col items-center justify-center py-6"
              >
                <svg
                  viewBox="0 0 320 120"
                  className="w-64 sm:w-80 h-auto overflow-visible"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <defs>
                    <linearGradient id="hello-grad" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor="#FFFFFF" />
                      <stop offset="35%" stopColor="#E0F2FE" />
                      <stop offset="70%" stopColor="#C084FC" />
                      <stop offset="100%" stopColor="#67E8F9" />
                    </linearGradient>
                    <filter id="hello-glow" x="-20%" y="-20%" width="140%" height="140%">
                      <feDropShadow dx="0" dy="0" stdDeviation="6" floodColor="#818CF8" floodOpacity="0.7" />
                    </filter>
                  </defs>

                  {/* Cursive "hello" Continuous Drawing Path */}
                  <motion.path
                    d="M 28 85 C 32 60 48 20 62 20 C 70 20 64 62 48 95 C 44 102 58 104 66 94 C 74 84 82 58 84 52 C 86 46 98 46 95 62 C 92 78 88 95 102 95 C 112 95 120 78 126 68 C 132 58 126 50 118 52 C 108 55 106 72 112 85 C 118 95 132 96 142 85 C 152 74 158 40 162 22 C 166 12 168 45 168 75 C 168 92 176 96 186 86 C 196 76 202 42 206 22 C 210 12 212 45 212 75 C 212 92 220 96 230 86 C 240 76 250 56 258 56 C 268 56 268 76 256 86 C 246 95 234 94 236 78 C 238 62 252 52 268 54 C 282 56 295 72 292 88"
                    stroke="url(#hello-grad)"
                    strokeWidth="4.5"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    filter="url(#hello-glow)"
                    initial={{ pathLength: 0, opacity: 0 }}
                    animate={{ pathLength: 1, opacity: 1 }}
                    transition={{
                      duration: 1.1,
                      ease: [0.65, 0, 0.35, 1],
                    }}
                  />
                </svg>

                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.5, duration: 0.5 }}
                  className="mt-3 text-xs tracking-[0.3em] uppercase text-sky-300/80 font-medium font-mono"
                >
                  Personal Life OS
                </motion.div>
              </motion.div>
            )}

            {/* Phase 2: Liquid Glass Emblem & Brand Reveal */}
            {phase === 'reveal' && (
              <motion.div
                initial={{ opacity: 0, scale: 0.88, y: 12 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 1.05 }}
                transition={{
                  type: 'spring',
                  stiffness: 420,
                  damping: 28,
                }}
                className="flex flex-col items-center gap-4"
              >
                {/* Frosted Glass Emblem Capsule */}
                <div className="relative p-3.5 rounded-[28px] bg-white/[0.04] border border-white/15 backdrop-blur-2xl shadow-[0_8px_32px_rgba(0,0,0,0.5),inset_0_1px_0_rgba(255,255,255,0.25)]">
                  <LuxuryRaaCrownMark size={64} />
                  {/* Subtle rim pulse */}
                  <div className="absolute inset-0 rounded-[28px] border border-cyan-400/30 animate-ping opacity-20 pointer-events-none" />
                </div>

                <div className="flex flex-col items-center gap-1">
                  <motion.h1
                    initial={{ opacity: 0, y: 6 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.1, duration: 0.4 }}
                    className="text-2xl sm:text-3xl font-bold tracking-tight text-white font-display"
                  >
                    Raa&apos;s Diary
                  </motion.h1>
                  <motion.p
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.2, duration: 0.4 }}
                    className="text-xs sm:text-sm text-sky-200/70 font-medium tracking-wide"
                  >
                    Your Daily Sanctuary &amp; Life OS
                  </motion.p>
                </div>

                {/* iPhone Dynamic Island Style Loading Bar */}
                <motion.div
                  initial={{ width: 0, opacity: 0 }}
                  animate={{ width: 84, opacity: 1 }}
                  transition={{ delay: 0.15, duration: 0.7, ease: 'easeOut' }}
                  className="h-1 rounded-full bg-gradient-to-r from-cyan-400 via-violet-400 to-pink-500 mt-2 shadow-[0_0_12px_rgba(56,189,248,0.8)]"
                />
              </motion.div>
            )}
          </div>

          {/* Bottom Tap to Continue Hint */}
          <div className="absolute bottom-6 sm:bottom-8 text-[11px] text-white/30 tracking-widest uppercase font-mono">
            Tap to open
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default AppleHelloSplash;
