import React from 'react';

interface AuraaIrisGlyphProps {
  size?: number;
  className?: string;
}

/**
 * AuraaIrisGlyph — High-Tech Sacred Geometry AI Core Iris (as in Pinterest Image 1 & 5):
 * Nested geometric rings with radiant cyan (#38BDF8) & violet (#A855F7) highlights.
 */
export const AuraaIrisGlyph: React.FC<AuraaIrisGlyphProps> = ({ size = 22, className = '' }) => {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 32 32"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`shrink-0 ${className}`}
      aria-hidden="true"
    >
      <defs>
        <linearGradient id="auraa-iris-g" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#EC4899" />
          <stop offset="50%" stopColor="#818CF8" />
          <stop offset="100%" stopColor="#38BDF8" />
        </linearGradient>
      </defs>
      {/* Outer Circle Ring */}
      <circle cx="16" cy="16" r="14" stroke="url(#auraa-iris-g)" strokeWidth="1.8" strokeOpacity="0.85" />
      {/* Inner Inscribed Hexagon / Triquetra Core */}
      <path
        d="M16 6L24.66 11V21L16 26L7.34 21V11L16 6Z"
        stroke="url(#auraa-iris-g)"
        strokeWidth="1.2"
        strokeOpacity="0.7"
      />
      {/* Central Ethereal Quantum Core */}
      <circle cx="16" cy="16" r="3.2" fill="#38BDF8" />
      <circle cx="16" cy="16" r="5.5" stroke="#EC4899" strokeWidth="0.8" strokeDasharray="2 2" />
    </svg>
  );
};
