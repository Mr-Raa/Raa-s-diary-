import type { SVGProps } from 'react';
import React from 'react';
import { LuxuryRaaCrownMark } from './LuxuryRaaCrownMark';

type RaaMarkProps = SVGProps<SVGSVGElement> & {
  size?: number;
  title?: string;
  className?: string;
};

/**
 * Official RaaMark — Powered by LuxuryRaaCrownMark:
 * Precision-cut architectural 'R' with Crown pinnacle, fluid loop, and dynamic velocity leg.
 */
export function RaaMark({
  size = 44,
  title = "Raa's Diary",
  className = '',
  ...props
}: RaaMarkProps) {
  return (
    <LuxuryRaaCrownMark
      size={size}
      title={title}
      className={className}
      {...props}
    />
  );
}

export default RaaMark;
