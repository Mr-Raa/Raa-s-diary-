import React, { useId } from 'react';
import { RaaMark } from './brand/RaaMark';

interface BrandLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showText?: boolean;
  subtitle?: string;
  labelOverride?: string;
  animated?: boolean;
}

/**
 * Raa's Diary — Official Luxury Monogram Liquid Glass Emblem:
 * Precision-cut obsidian squircle with specular rim, ambient violet/cyan aura,
 * and bespoke high-end 'R' emblem.
 */
export const BrandLogo: React.FC<BrandLogoProps> = ({
  size = 'md',
  showText = false,
  subtitle,
  labelOverride,
  animated = false,
}) => {
  const uid = useId().replace(/:/g, '');
  const bgId = `raa-bg-${uid}`;
  const glowId = `raa-glow-${uid}`;
  const rimId = `raa-rim-${uid}`;

  const dim =
    size === 'xl'
      ? 'w-16 h-16 rounded-[24%]'
      : size === 'lg'
        ? 'w-12 h-12 rounded-[24%]'
        : size === 'sm'
          ? 'w-8 h-8 rounded-[24%]'
          : 'w-9 h-9 rounded-[24%]';

  const markSize =
    size === 'xl'
      ? 46
      : size === 'lg'
        ? 34
        : size === 'sm'
          ? 22
          : 26;

  return (
    <div className="flex items-center gap-2.5 min-w-0 shrink-0">
      <div
        className={`${dim} relative shrink-0 overflow-hidden shadow-[0_4px_20px_rgba(2,6,23,0.6),0_1px_3px_rgba(255,255,255,0.1),inset_0_1px_0_rgba(255,255,255,0.3)] border border-white/10 ${
          animated ? 'transition-transform duration-300 hover:scale-105' : ''
        }`}
        aria-hidden="true"
      >
        <svg viewBox="0 0 64 64" className="w-full h-full block">
          <defs>
            {/* Deep Space Obsidian Gradient */}
            <linearGradient id={bgId} x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#0e1322" />
              <stop offset="50%" stopColor="#080c16" />
              <stop offset="100%" stopColor="#02040a" />
            </linearGradient>

            {/* Ambient Dual-Tone Glow (Violet Top-Left, Cyan Bottom-Right) */}
            <radialGradient id={glowId} cx="35%" cy="30%" r="70%">
              <stop offset="0%" stopColor="#818cf8" stopOpacity="0.32" />
              <stop offset="50%" stopColor="#38bdf8" stopOpacity="0.18" />
              <stop offset="100%" stopColor="#020617" stopOpacity="0" />
            </radialGradient>

            {/* Specular Edge Stroke */}
            <linearGradient id={rimId} x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#ffffff" stopOpacity="0.5" />
              <stop offset="50%" stopColor="#818cf8" stopOpacity="0.25" />
              <stop offset="100%" stopColor="#38bdf8" stopOpacity="0.15" />
            </linearGradient>
          </defs>

          {/* Background Squircle */}
          <rect width="64" height="64" rx="15" fill={`url(#${bgId})`} />
          <rect width="64" height="64" rx="15" fill={`url(#${glowId})`} />

          {/* Specular Rim */}
          <rect
            x="0.75"
            y="0.75"
            width="62.5"
            height="62.5"
            rx="14.5"
            fill="none"
            stroke={`url(#${rimId})`}
            strokeWidth="1.2"
          />
        </svg>

        {/* Center Bespoke Raa Monogram */}
        <div className="absolute inset-0 flex items-center justify-center text-white pointer-events-none">
          <RaaMark size={markSize} />
        </div>
      </div>

      {showText && (
        <div className="min-w-0">
          <div
            className={`font-display font-bold tracking-tight whitespace-nowrap truncate leading-tight ${
              size === 'xl'
                ? 'text-xl'
                : size === 'lg'
                  ? 'text-lg'
                  : size === 'sm'
                    ? 'text-[15px]'
                    : 'text-[15.5px]'
            }`}
          >
            {labelOverride || "Raa's Diary"}
          </div>
          <div className="text-[11px] text-[var(--text-muted)] whitespace-nowrap truncate">
            {subtitle ?? 'Personal Life OS'}
          </div>
        </div>
      )}
    </div>
  );
};
