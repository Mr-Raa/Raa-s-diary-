import React, { useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { motion } from 'motion/react';
import {
  Activity,
  AlarmClock,
  Bell,
  BookOpen,
  Briefcase,
  Calendar as CalendarIcon,
  Check,
  CheckSquare,
  Clock,
  Droplets,
  FileText,
  History,
  Home,
  LayoutGrid,
  Lock,
  Moon,
  Palette,
  Search,
  Settings as SettingsIcon,
  Sparkles,
  Sun,
  Target,
  Timer,
  Unlock,
  User,
  X,
} from 'lucide-react';
import type { AppNotification, AppSettings, NavModule, UserProfile } from '../types';
import { formatDateReadable } from '../utils/dateLogic';
import { PWAInstallButton } from '../hooks/usePWAInstall';
import { BrandLogo } from './BrandLogo';

export interface NavItem {
  id: NavModule;
  label: string;
  mobileLabel?: string;
  icon: React.ComponentType<{ className?: string }>;
}

export const NAV_ITEMS: NavItem[] = [
  { id: 'dashboard', label: 'Home', mobileLabel: 'Home', icon: Home },
  { id: 'routine', label: 'My Routine', mobileLabel: 'Routine', icon: Clock },
  { id: 'tasks', label: 'Tasks', mobileLabel: 'Tasks', icon: CheckSquare },
  { id: 'alarms', label: 'Alarms', mobileLabel: 'Alarms', icon: AlarmClock },
  { id: 'calendar', label: 'Calendar', mobileLabel: 'Calendar', icon: CalendarIcon },
  { id: 'trackers', label: 'Trackers', mobileLabel: 'Trackers', icon: Droplets },
  { id: 'goals', label: 'Goals & Habits', mobileLabel: 'Goals', icon: Target },
  { id: 'study', label: 'Study', mobileLabel: 'Study', icon: BookOpen },
  { id: 'work', label: 'Work', mobileLabel: 'Work', icon: Briefcase },
  { id: 'focus', label: 'Focus Mode', mobileLabel: 'Focus', icon: Timer },
  { id: 'notes', label: 'Notes & Diary', mobileLabel: 'Diary', icon: FileText },
  { id: 'analytics', label: 'Analytics', mobileLabel: 'Analytics', icon: Activity },
  { id: 'history', label: 'History', mobileLabel: 'History', icon: History },
  { id: 'ai', label: 'AURAA AI', mobileLabel: 'AURAA', icon: Sparkles },
  { id: 'settings', label: 'Settings', mobileLabel: 'Settings', icon: SettingsIcon },
];

export const MOBILE_PRIMARY_TABS: NavModule[] = [
  'dashboard',
  'routine',
  'tasks',
  'notes',
  'ai',
  'settings',
];

interface LiveClockProps {
  timezone: string;
  timeFormat: '12h' | '24h';
}

const LiveClock: React.FC<LiveClockProps> = React.memo(({ timezone, timeFormat }) => {
  const [clock, setClock] = useState('');

  useEffect(() => {
    const updateClock = () => {
      try {
        const formatted = new Intl.DateTimeFormat('en-IN', {
          timeZone: timezone || 'Asia/Kolkata',
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
          hour12: timeFormat === '12h',
        }).format(new Date());
        setClock(formatted);
      } catch {
        setClock(new Date().toLocaleTimeString());
      }
    };

    const isWide =
      typeof window !== 'undefined' ? window.matchMedia('(min-width: 640px)').matches : true;
    if (!isWide) return;

    updateClock();
    const t = window.setInterval(updateClock, 1000);
    return () => window.clearInterval(t);
  }, [timezone, timeFormat]);

  if (!clock) return null;

  return (
    <div
      className="hidden sm:block font-mono-num text-xs sm:text-sm text-[var(--text-secondary)] px-2.5 py-1.5 rounded-xl bg-white/[0.04] whitespace-nowrap"
      aria-label="Live clock"
    >
      {clock}
    </div>
  );
});
LiveClock.displayName = 'LiveClock';

interface SidebarProps {
  active: NavModule;
  onSelect: (m: NavModule) => void;
  user: UserProfile;
  settings: AppSettings;
  onOpenAuth?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ active, onSelect, user, settings, onOpenAuth }) => {
  return (
    <aside
      className="hidden lg:flex flex-col w-[248px] shrink-0 h-screen sticky top-0 glass-sidebar z-20 px-3.5 py-5 justify-between"
      aria-label="Primary navigation"
    >
      <div className="space-y-5 overflow-y-auto pr-1">
        <div className="px-2">
          <BrandLogo size="md" showText subtitle="Personal Life OS" />
        </div>

        <nav className="space-y-1">
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const isActive = active === item.id;
            const textLabel = item.label;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => onSelect(item.id)}
                aria-current={isActive ? 'page' : undefined}
                className={`relative w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-left whitespace-nowrap transition-colors ${
                  isActive
                    ? 'text-[var(--text-primary)] font-semibold'
                    : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:bg-slate-500/10'
                }`}
              >
                {isActive && (
                  <motion.span
                    layoutId="sidebar-liquid-pill"
                    transition={{ type: 'spring', stiffness: 440, damping: 32 }}
                    className="absolute inset-0 rounded-xl glass-active-pill -z-10"
                    aria-hidden="true"
                  />
                )}
                <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-[var(--accent)]' : ''}`} />
                <span className="truncate">{textLabel}</span>
              </button>
            );
          })}
        </nav>
      </div>

      <div className="pt-3 border-t border-[var(--glass-border-subtle)] px-1">
        <button
          type="button"
          onClick={() => (onOpenAuth ? onOpenAuth() : onSelect('settings'))}
          className="w-full flex items-center gap-3 p-2.5 rounded-xl hover:bg-slate-900/[0.05] dark:hover:bg-white/[0.06] transition-colors text-left"
        >
          <div className="w-8 h-8 rounded-full bg-[var(--accent)]/15 border border-[var(--accent)]/30 flex items-center justify-center shrink-0 text-[var(--accent)]">
            <User className="w-4 h-4 text-[var(--accent)]" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="text-xs font-semibold truncate">{user.name}</div>
            <div className="text-[11px] text-[var(--text-muted)] truncate">{user.email}</div>
          </div>
        </button>
      </div>
    </aside>
  );
};

export const THEME_PRESETS = [
  { name: 'Royal Blue', hex: '#6b9cff' },
  { name: 'Lavender Violet', hex: '#a78bfa' },
  { name: 'Neon Cyan', hex: '#38bdf8' },
  { name: 'Emerald Mint', hex: '#55d6a5' },
  { name: 'Warm Amber', hex: '#f5bb68' },
  { name: 'Rose Coral', hex: '#f43f5e' },
  { name: 'Hot Pink', hex: '#ec4899' },
  { name: 'Forest Green', hex: '#10b981' },
  { name: 'Sunset Orange', hex: '#f97316' },
];

interface TopBarProps {
  active: NavModule;
  today: string;
  user: UserProfile;
  settings: AppSettings;
  notifications: AppNotification[];
  onToggleTheme: () => void;
  onUpdateAccentColor?: (color: string) => void;
  onMarkAllRead: () => void;
  onSelectModule: (m: NavModule) => void;
  onOpenAuth: () => void;
  onOpenInstallGuide?: () => void;
  onOpenModulesMenu?: () => void;
  onOpenCommandPalette?: () => void;
}

export const TopBar: React.FC<TopBarProps> = ({
  active,
  today,
  user,
  settings,
  notifications,
  onToggleTheme,
  onUpdateAccentColor,
  onMarkAllRead,
  onSelectModule,
  onOpenAuth,
  onOpenInstallGuide,
  onOpenModulesMenu,
  onOpenCommandPalette,
}) => {
  const [notifOpen, setNotifOpen] = useState(false);

  const unreadCount = notifications.filter((n) => !n.read).length;
  const activeItem = NAV_ITEMS.find((n) => n.id === active);

  return (
    <header className="max-md:relative md:sticky md:top-0 z-30 shrink-0 glass-topbar max-md:min-h-[48px] max-md:px-2.5 pt-[max(0.35rem,env(safe-area-inset-top))] pb-1 sm:px-6 sm:py-3 flex items-center justify-between gap-2 sm:gap-4">
      {/* Left: Brand / Active Module */}
      <div className="flex items-center gap-2 sm:gap-3 min-w-0">
        <motion.button
          type="button"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.94 }}
          transition={{ type: 'spring', stiffness: 460, damping: 28 }}
          onClick={() => onSelectModule('dashboard')}
          aria-label="Go to Raa's Diary Home"
          className="lg:hidden shrink-0 flex items-center min-w-0 text-left"
        >
          <BrandLogo
            size="sm"
            showText
            animated
            labelOverride={active === 'dashboard' ? "Raa's Diary" : activeItem?.mobileLabel || activeItem?.label}
          />
        </motion.button>
        <span className="hidden lg:inline text-sm font-semibold tracking-tight whitespace-nowrap">
          {activeItem?.label ?? 'Home'}
        </span>
      </div>

      {/* Center: Unified Non-Colliding Date & Clock Badge */}
      <div className="hidden xl:flex items-center gap-2 px-3 py-1.5 rounded-xl bg-white/[0.04] border border-white/5 text-xs text-[var(--text-secondary)] whitespace-nowrap shrink-0">
        <span className="font-medium text-[var(--text-primary)]">
          {formatDateReadable(today, settings.dateFormat)}
        </span>
        <span className="opacity-30" aria-hidden="true">|</span>
        <LiveClock timezone={settings.timezone} timeFormat={settings.timeFormat} />
      </div>

      {/* Right: Essential Clean Action Controls */}
      <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
        {/* Notifications Popover */}
        <div className="relative">
          <button
            type="button"
            onClick={() => setNotifOpen((v) => !v)}
            aria-label={`Notifications (${unreadCount} unread)`}
            title="Notifications"
            className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-slate-900/[0.055] hover:bg-slate-900/[0.10] dark:bg-white/[0.05] dark:hover:bg-white/[0.10] flex items-center justify-center relative active:scale-95 transition-all cursor-pointer"
          >
            <Bell className="w-4 h-4 text-[var(--text-secondary)]" />
            {unreadCount > 0 && (
              <span className="absolute -top-0.5 -right-0.5 w-4 h-4 rounded-full bg-[var(--accent)] text-white text-[10px] font-bold flex items-center justify-center">
                {unreadCount}
              </span>
            )}
          </button>

          {notifOpen && (
            <>
              {/* Outside-tap closer */}
              <div
                className="fixed inset-0 z-40"
                onClick={() => setNotifOpen(false)}
                aria-hidden="true"
              />
              <div className="absolute right-0 mt-2 w-80 max-w-[90vw] glass-modal p-4 z-50 space-y-3 rounded-2xl shadow-2xl border border-white/20 bg-[#0c1222]/95 backdrop-blur-2xl">
                <div className="flex items-center justify-between border-b border-white/10 pb-2.5">
                  <span className="text-xs font-bold tracking-tight text-white uppercase">Notifications</span>
                  {notifications.length > 0 && (
                    <button
                      type="button"
                      onClick={() => {
                        onMarkAllRead();
                        setNotifOpen(false);
                      }}
                      className="text-[11px] text-[var(--accent)] hover:underline font-semibold"
                    >
                      Mark all read
                    </button>
                  )}
                </div>
                <div className="space-y-2 max-h-64 overflow-y-auto no-scrollbar">
                  {notifications.length === 0 ? (
                    <div className="py-4 text-center space-y-2">
                      <div className="w-8 h-8 rounded-full bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center mx-auto text-emerald-400">
                        <Check className="w-4 h-4" />
                      </div>
                      <p className="text-xs font-semibold text-white">All caught up!</p>
                      <p className="text-[11px] text-[var(--text-muted)]">No pending alerts right now.</p>
                      <div className="flex justify-center gap-2 pt-1">
                        <button
                          type="button"
                          onClick={() => {
                            setNotifOpen(false);
                            onSelectModule('tasks');
                          }}
                          className="px-2.5 py-1 rounded-lg bg-white/[0.08] hover:bg-white/[0.14] text-[11px] text-sky-300 font-medium"
                        >
                          View Tasks
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            setNotifOpen(false);
                            onSelectModule('alarms');
                          }}
                          className="px-2.5 py-1 rounded-lg bg-white/[0.08] hover:bg-white/[0.14] text-[11px] text-violet-300 font-medium"
                        >
                          View Alarms
                        </button>
                      </div>
                    </div>
                  ) : (
                    notifications.slice(0, 8).map((n) => (
                      <div
                        key={n.id}
                        className={`p-2.5 rounded-xl border transition-all ${
                          n.read
                            ? 'bg-white/[0.02] border-white/5 opacity-60'
                            : 'bg-white/[0.08] border-white/15'
                        }`}
                      >
                        <div className="text-xs font-semibold text-white">{n.title}</div>
                        <div className="text-xs text-[var(--text-secondary)] mt-0.5">{n.message}</div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </>
          )}
        </div>

        {/* Mobile Profile / All Modules Trigger (< lg) */}
        <button
          type="button"
          onClick={() => (onOpenModulesMenu ? onOpenModulesMenu() : onOpenAuth())}
          aria-label="Profile and All Modules"
          title="Account / Menu"
          className="lg:hidden w-8 h-8 sm:w-9 sm:h-9 rounded-full bg-white/[0.08] hover:bg-white/[0.15] border border-white/15 flex items-center justify-center relative active:scale-95 transition-all cursor-pointer"
        >
          <User className="w-4 h-4 text-sky-300" />
        </button>

        {/* Desktop/Tablet Account Trigger */}
        <div className="hidden lg:flex items-center gap-2">
          <button
            type="button"
            onClick={onOpenAuth}
            aria-label="Account and Profile"
            className="min-w-[40px] min-h-[40px] px-3 rounded-xl bg-slate-900/[0.055] hover:bg-slate-900/[0.10] dark:bg-white/[0.05] dark:hover:bg-white/[0.10] flex items-center justify-center gap-2 whitespace-nowrap transition-all cursor-pointer"
          >
            <User className="w-4 h-4 text-[var(--text-secondary)]" />
            <span className="hidden md:inline text-xs font-medium">{user.name}</span>
          </button>
        </div>

        {/* AURAA AI Quick Action Button */}
        <motion.button
          type="button"
          whileHover={{ scale: 1.05, y: -1 }}
          whileTap={{ scale: 0.93 }}
          transition={{ type: 'spring', stiffness: 460, damping: 26 }}
          onClick={() => onSelectModule('ai')}
          aria-label="Ask AURAA AI"
          className="hidden sm:flex glass-button-primary auraa-btn-animated px-3 sm:px-3.5 h-10 text-xs font-semibold items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
        >
          <Sparkles className="w-3.5 h-3.5 auraa-spark-animated" />
          <span className="relative z-10 tracking-wide">AURAA</span>
        </motion.button>
      </div>
    </header>
  );
};

interface MobileNavProps {
  active: NavModule;
  onSelect: (m: NavModule) => void;
  user?: UserProfile;
  settings: AppSettings;
  modulesSheetOpen: boolean;
  onSetModulesSheetOpen: (open: boolean) => void;
  onToggleTheme: () => void;
  onOpenAuth?: () => void;
  onOpenInstallGuide?: () => void;
}

export const MobileNav: React.FC<MobileNavProps> = ({
  active,
  onSelect,
  user,
  settings,
  modulesSheetOpen,
  onSetModulesSheetOpen,
  onToggleTheme,
  onOpenAuth,
  onOpenInstallGuide,
}) => {
  const secondaryItems = NAV_ITEMS.filter((i) => !MOBILE_PRIMARY_TABS.includes(i.id));
  const [navHidden, setNavHidden] = useState(false);
  const lastScrollY = useRef(0);

  // Windows / iOS Taskbar Auto-Hide on scroll down, show on scroll up
  useEffect(() => {
    let timeoutId: number | undefined;

    const handleScroll = () => {
      const currentScrollY = window.scrollY || document.documentElement.scrollTop;
      const diff = currentScrollY - lastScrollY.current;

      if (diff > 18 && currentScrollY > 70) {
        // Scrolling down -> Auto hide taskbar
        setNavHidden(true);
      } else if (diff < -10 || currentScrollY <= 20) {
        // Scrolling up or at top -> Reveal taskbar
        setNavHidden(false);
      }
      lastScrollY.current = Math.max(0, currentScrollY);

      // Auto reveal after idle
      window.clearTimeout(timeoutId);
      timeoutId = window.setTimeout(() => {
        setNavHidden(false);
      }, 3500);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => {
      window.removeEventListener('scroll', handleScroll);
      window.clearTimeout(timeoutId);
    };
  }, []);

  const drawerPortal =
    modulesSheetOpen && typeof document !== 'undefined'
      ? createPortal(
          <div
            className="lg:hidden fixed inset-0 z-[9999] bg-black/65 md:backdrop-blur-sm flex items-end"
            onClick={() => onSetModulesSheetOpen(false)}
          >
            <div
              className="glass-modal ios-sheet-up w-full p-4 sm:p-5 pb-[max(2rem,env(safe-area-inset-bottom))] rounded-t-[28px] max-h-[85dvh] overflow-y-auto no-scrollbar"
              onClick={(e) => e.stopPropagation()}
            >
              <div
                className="w-10 h-1 rounded-full bg-slate-400/35 mx-auto mb-3.5"
                aria-hidden="true"
              />
              <div className="flex items-center justify-between mb-3.5">
                <div className="flex items-center gap-2">
                  <LayoutGrid className="w-4 h-4 text-[var(--accent)]" />
                  <span className="text-base font-semibold">Profile &amp; All Modules</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={onToggleTheme}
                    aria-label={settings.theme === 'light' ? 'Switch to Dark theme' : 'Switch to Light theme'}
                    className="glass-button w-10 h-10 flex items-center justify-center"
                  >
                    {settings.theme === 'light' ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
                  </button>
                  <button
                    type="button"
                    onClick={() => onSetModulesSheetOpen(false)}
                    aria-label="Close modules menu"
                    className="glass-button p-2 min-w-[44px] min-h-[44px] flex items-center justify-center"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-between gap-2.5 mb-3.5 p-2.5 rounded-2xl bg-slate-900/[0.045] dark:bg-white/[0.045]">
                {onOpenAuth ? (
                  <button
                    type="button"
                    onClick={() => {
                      onSetModulesSheetOpen(false);
                      onOpenAuth();
                    }}
                    className="flex items-center gap-2.5 min-w-0 text-left flex-1 py-1 px-1"
                  >
                    <div className="w-9 h-9 rounded-full bg-[var(--accent)]/15 border border-[var(--accent)]/30 flex items-center justify-center shrink-0 text-[var(--accent)]">
                      <User className="w-4 h-4 text-[var(--accent)]" />
                    </div>
                    <div className="min-w-0">
                      <div className="text-xs font-semibold truncate">{user?.name || 'Account'}</div>
                      <div className="text-[11px] text-[var(--text-muted)] truncate">
                        Account &amp; Sync
                      </div>
                    </div>
                  </button>
                ) : null}
                <PWAInstallButton
                  onOpenInstallGuide={() => {
                    onSetModulesSheetOpen(false);
                    onOpenInstallGuide?.();
                  }}
                />
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 pb-4">
                {secondaryItems.map((item) => {
                  const Icon = item.icon;
                  const isActive = active === item.id;
                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => {
                        onSelect(item.id);
                        onSetModulesSheetOpen(false);
                      }}
                      className={`min-h-[48px] flex items-center gap-2.5 px-3.5 py-3 rounded-2xl text-xs font-medium text-left active:scale-[0.98] transition-transform ${
                        isActive ? 'glass-button-primary text-white' : 'glass-button'
                      }`}
                    >
                      <Icon className="w-4 h-4 shrink-0" />
                      <span className="truncate">{item.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>,
          document.body
        )
      : null;

  return (
    <>
      {/* Floating Auto-Hide Handle when nav is concealed */}
      {navHidden && (
        <button
          type="button"
          onClick={() => setNavHidden(false)}
          aria-label="Show navigation bar"
          className="lg:hidden fixed bottom-2 left-1/2 -translate-x-1/2 z-40 px-4 py-1 rounded-full bg-white/20 backdrop-blur-xl border border-white/25 shadow-lg flex items-center gap-1.5 text-[10px] text-white/90 animate-pulse cursor-pointer"
        >
          <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
          <span>Menu</span>
        </button>
      )}

      <nav
        style={{
          transform: navHidden ? 'translateY(115%)' : 'translateY(0%)',
          transition: 'transform 0.32s cubic-bezier(0.16, 1, 0.3, 1), opacity 0.28s ease',
          opacity: navHidden ? 0 : 1,
          paddingBottom: 'calc(env(safe-area-inset-bottom, 0px) + 8px)',
          paddingLeft: 'max(0.25rem, env(safe-area-inset-left, 0px))',
          paddingRight: 'max(0.25rem, env(safe-area-inset-right, 0px))',
        }}
        className="lg:hidden fixed bottom-0 inset-x-0 z-40 glass-mobile-tabbar pt-1.5"
        aria-label="Mobile navigation"
      >
        <div className="grid grid-cols-6 gap-0.5 sm:gap-1">
          {MOBILE_PRIMARY_TABS.map((id) => {
            const item = NAV_ITEMS.find((n) => n.id === id)!;
            const Icon = item.icon;
            const isActive = active === id;
            const shortLabel = item.mobileLabel || item.label;
            return (
              <motion.button
                key={id}
                type="button"
                whileTap={{ scale: 0.92 }}
                onClick={() => {
                  onSelect(id);
                  onSetModulesSheetOpen(false);
                }}
                aria-current={isActive ? 'page' : undefined}
                className={`relative min-h-[46px] flex flex-col items-center justify-center rounded-2xl text-[10.5px] font-medium transition-colors ${
                  isActive ? 'text-[var(--text-primary)] font-semibold' : 'text-[var(--text-secondary)]'
                }`}
              >
                {isActive && (
                  <motion.span
                    layoutId="mobile-tab-liquid-pill"
                    transition={{ type: 'spring', stiffness: 460, damping: 32 }}
                    className="absolute inset-0.5 rounded-2xl glass-active-pill -z-10"
                    aria-hidden="true"
                  />
                )}
                <motion.span
                  animate={{ scale: isActive ? 1.12 : 1, y: isActive ? -1 : 0 }}
                  transition={{ type: 'spring', stiffness: 480, damping: 28 }}
                  className="inline-flex"
                >
                  <Icon className={`w-[18px] h-[18px] mb-0.5 ${isActive ? 'text-[var(--accent)]' : ''}`} />
                </motion.span>
                <span className="truncate max-w-full px-0.5">{shortLabel}</span>
              </motion.button>
            );
          })}
        </div>
      </nav>
      {drawerPortal}
    </>
  );
};
