import React from 'react';
import { LuxuryRaaCrownMark } from './brand/LuxuryRaaCrownMark';

interface BrandLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showText?: boolean;
  subtitle?: string;
  labelOverride?: string;
  animated?: boolean;
}

/**
 * BrandLogo — Official Minimalist Liquid Glass Sanctuary Emblem:
 * Precision-cut obsidian squircle with specular rim, ambient violet/cyan aura,
 * and minimalist geometric Sanctuary Prism emblem.
 */
export const BrandLogo: React.FC<BrandLogoProps> = ({
  size = 'md',
  showText = false,
  subtitle,
  labelOverride,
  animated = false,
}) => {
  const pixelSize =
    size === 'xl' ? 56 : size === 'lg' ? 44 : size === 'sm' ? 28 : 34;

  return (
    <div className="flex items-center gap-2.5 min-w-0 shrink-0 select-none">
      <div
        className={`relative shrink-0 overflow-hidden rounded-[24%] shadow-[0_4px_20px_rgba(2,6,23,0.6),0_1px_3px_rgba(255,255,255,0.1)] ${
          animated ? 'transition-transform duration-300 hover:scale-105 active:scale-95' : ''
        }`}
        aria-hidden="true"
      >
        <LuxuryRaaCrownMark size={pixelSize} />
      </div>

      {showText && (
        <div className="min-w-0">
          <div
            className={`font-display font-bold tracking-tight whitespace-nowrap truncate leading-tight ${
              size === 'xl'
                ? 'text-xl'
                : size === 'lg'
                  ? 'text-lg'
                  : size === 'sm'
                    ? 'text-[15px]'
                    : 'text-[15.5px]'
            }`}
          >
            {labelOverride || "Raa's Diary"}
          </div>
          <div className="text-[11px] text-[var(--text-muted)] whitespace-nowrap truncate">
            {subtitle ?? 'Personal Life OS'}
          </div>
        </div>
      )}
    </div>
  );
};

export default BrandLogo;
