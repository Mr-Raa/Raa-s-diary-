import type { SVGProps } from 'react';
import React, { useId } from 'react';

interface LuxuryRaaMarkProps extends SVGProps<SVGSVGElement> {
  size?: number;
  title?: string;
  className?: string;
}

/**
 * LuxurySanctuaryEmblem — Ultra-Clean Minimalist Sanctuary Prism:
 * 100% Minimalist, Luxury Identity for Raa's Diary.
 * Zero letter shapes — pure architectural geometry:
 * - Obsidian squircle with liquid-glass rim highlight.
 * - Geometric dual-facet Sanctuary Prism (open journal / life vault).
 * - Central 4-point luminous celestial beacon / star.
 * - Pure, balanced, modern luxury aesthetic.
 */
export const LuxuryRaaCrownMark: React.FC<LuxuryRaaMarkProps> = ({
  size = 48,
  title = "Raa's Diary",
  className = '',
  ...props
}) => {
  const uid = useId().replace(/:/g, '');
  const bgGrad = `sanctuary-bg-${uid}`;
  const rimGrad = `sanctuary-rim-${uid}`;
  const prismGrad = `sanctuary-prism-${uid}`;
  const prismGrad2 = `sanctuary-prism2-${uid}`;
  const glowFilter = `sanctuary-glow-${uid}`;

  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 128 128"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      role="img"
      aria-label={title}
      className={`shrink-0 select-none ${className}`}
      {...props}
    >
      <title>{title}</title>
      <defs>
        {/* Deep Space Obsidian Squircle */}
        <radialGradient id={bgGrad} cx="45%" cy="35%" r="75%">
          <stop offset="0%" stopColor="#141829" />
          <stop offset="50%" stopColor="#0a0d18" />
          <stop offset="100%" stopColor="#04060c" />
        </radialGradient>

        {/* Specular Violet-to-Cyan Edge Rim */}
        <linearGradient id={rimGrad} x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#FFFFFF" stopOpacity="0.85" />
          <stop offset="35%" stopColor="#C084FC" stopOpacity="0.6" />
          <stop offset="70%" stopColor="#818CF8" stopOpacity="0.45" />
          <stop offset="100%" stopColor="#38BDF8" stopOpacity="0.75" />
        </linearGradient>

        {/* Prism Facet 1 (Left Wing / Folio) */}
        <linearGradient id={prismGrad} x1="20%" y1="20%" x2="90%" y2="90%">
          <stop offset="0%" stopColor="#FFFFFF" />
          <stop offset="40%" stopColor="#C4B5FD" />
          <stop offset="100%" stopColor="#6366F1" />
        </linearGradient>

        {/* Prism Facet 2 (Right Wing / Folio) */}
        <linearGradient id={prismGrad2} x1="80%" y1="20%" x2="10%" y2="90%">
          <stop offset="0%" stopColor="#E0F2FE" />
          <stop offset="45%" stopColor="#38BDF8" />
          <stop offset="100%" stopColor="#818CF8" />
        </linearGradient>

        {/* Soft Specular Aura */}
        <filter id={glowFilter} x="-20%" y="-20%" width="140%" height="140%">
          <feDropShadow dx="0" dy="2" stdDeviation="4" floodColor="#818CF8" floodOpacity="0.4" />
        </filter>
      </defs>

      {/* 1. Base Squircle */}
      <rect x="4" y="4" width="120" height="120" rx="30" fill={`url(#${bgGrad})`} />
      <rect
        x="4.75"
        y="4.75"
        width="118.5"
        height="118.5"
        rx="29.25"
        fill="none"
        stroke={`url(#${rimGrad})`}
        strokeWidth="1.5"
      />

      {/* 2. Soft Ambient Core Aura */}
      <circle cx="64" cy="64" r="32" fill="#818CF8" opacity="0.12" filter="blur(16px)" />

      {/* 3. Minimalist Sanctuary Prism: Interlocking Diamond Folio */}
      <g filter={`url(#${glowFilter})`}>
        {/* Left Facet: Sweeping precision wing */}
        <path
          d="M64 28L38 56L64 88L55 88L32 56L55 28H64Z"
          fill={`url(#${prismGrad})`}
        />
        {/* Right Facet: Symmetrical balancing wing */}
        <path
          d="M64 28L90 56L64 88L73 88L96 56L73 28H64Z"
          fill={`url(#${prismGrad2})`}
        />
        {/* Central Vertical Light Beam / Spine */}
        <path
          d="M63 34H65V82H63V34Z"
          fill="#FFFFFF"
          opacity="0.85"
        />

        {/* 4. Center Luminous 4-Point Celestial Spark */}
        <g transform="translate(64, 56)">
          <path
            d="M0 -9C0.6 -2.5 2.5 -0.6 9 0C2.5 0.6 0.6 2.5 0 9C-0.6 2.5 -2.5 0.6 -9 0C-2.5 -0.6 -0.6 -2.5 0 -9Z"
            fill="#FFFFFF"
          />
          <circle cx="0" cy="0" r="2" fill="#38BDF8" />
        </g>

        {/* Subtle Bottom Accent Diamond */}
        <polygon
          points="64,95 67,99 64,103 61,99"
          fill="#C084FC"
          opacity="0.9"
        />
      </g>
    </svg>
  );
};

export default LuxuryRaaCrownMark;
